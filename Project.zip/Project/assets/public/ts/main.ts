if (document.readyState === "complete") {
  let score = (document.getElementById("score") as HTMLInputElement).value;
  score = "2";
}
